/*
 * professor.h
 *
 *  Created on: 12.06.2010
 *      Author: jule
 */

#ifndef PROFESSOR_H_
#define PROFESSOR_H_


#endif /* PROFESSOR_H_ */
