/*
 * Mitarbeiter.h
 *
 *  Created on: 12.06.2010
 *      Author: jule
 */
#ifndef MITARBEITER_H_
#define MITARBEITER_H_
#include "Person.h"
#include "Dienstzimmer.h"
#include "Email.h"
#include "Telefon.h"

class Mitarbeiter : public Person{
	private:
		Dienstzimmer raum;
		Telefon telefon;
		Telefon fax;
		Email email;
		string funktion;
	public:
		Mitarbeiter::Mitarbeiter();
		Mitarbeiter::~Mitarbeiter();
		virtual void zeige_person();
};

#endif /* MITARBEITER_H_ */

