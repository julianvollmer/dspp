/*
 * Datum.h
 *
 *  Created on: 13.06.2010
 *      Author: jule
 */

#ifndef DATUM_H_
#define DATUM_H_
#include <iostream>
using namespace std;
class Datum{
	private:
		int tag;
		int monat;
		int jahr;
	public:
		Datum();
		void zeige_datum_DE();
};

#endif /* DATUM_H_ */
