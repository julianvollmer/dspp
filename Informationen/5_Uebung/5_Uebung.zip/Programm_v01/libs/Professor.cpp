/*
 * professor.cpp
 *
 *  Created on: 12.06.2010
 *      Author: jule
 */
#ifndef PROFESSOR_CPP_
#define PROFESSOR_CPP_
#include "Professor.h"

#endif /* PROFESSOR_CPP_ */
