#include "mein_zufall.h"
/**
 * Initialisiert den Zufallsgenerator. Wenn er einmal initialisiert wurde, wird er nicht ein 2. mal initialisiert.
**/
int init = 0;

void initialisiere_zufall( void ){	
	if (init == 0) {
		srand((unsigned)time(NULL));
		init = 1;
	}
}
/**
 * Liefert eine Ganzzahlige Zufallszahl aus dem Bereich max und min.
 * @param min Mindester Wert den eine Zufallszahl annehmen darf.
 * @param max Maximaler Wert den eine Zufallszahl annehmen darf.
**/
int liefere_ganze_zufallszahl(int min, int max) {
	if(init == 0){
		initialisiere_zufall();
	}
	int bereich = max - min ;
	return (rand() % bereich) + min;
}
int liefere_ganze_zufallszahl() {
	if(init == 0){
		initialisiere_zufall();
	}
	return rand();
}
