#ifndef MEIN_ZUFALL
#define MEIN_ZUFALL
#include <stdlib.h>
#include <time.h>
void initialisiere_zufall();
int liefere_ganze_zufallszahl(int min, int max);
int liefere_ganze_zufallszahl();
#endif
