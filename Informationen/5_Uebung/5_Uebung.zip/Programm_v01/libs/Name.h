/*
 * Name.h
 *
 *  Created on: 12.06.2010
 *      Author: jule
 */

#ifndef NAME_H_
#define NAME_H_
#include <iostream>
using namespace std;
#include "mein_zufall.h"


class Name{
	private:
		string vorname;
		string nachname;
		string title;
		string geburtsname;
		char geschlecht;
	public:
		Name();
		void zeige_name();
		string get_vorname();
		string get_nachname();
		string get_geburtsname();
		string get_title();
};

#endif /* NAME_H_ */
