/*
 * Datum.cpp
 *
 *  Created on: 13.06.2010
 *      Author: jule
 */

#include "Datum.h"
Datum::Datum(){
	jahr = 1234;
	tag = 12;
	monat = 12;
}

void Datum::zeige_datum_DE(){
	cout << tag << "." << monat << "." << jahr <<endl;
}
