/*
 * Email.cpp
 *
 *  Created on: 13.06.2010
 *      Author: jule
 */

#include "Email.h"

Email::Email(){
	email = "me@htw-berlin.de";
}

void Email::set_email(string die_email){
	this->email = die_email;
}

void Email::zeige_email(){
	cout << email;
}
