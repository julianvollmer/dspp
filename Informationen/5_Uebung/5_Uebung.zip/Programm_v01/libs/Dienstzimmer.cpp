/*
 * Dienstzimmer.cpp
 *
 *  Created on: 20.06.2010
 *      Author: jule
 */
#include "Dienstzimmer.h"

Dienstzimmer::Dienstzimmer(){
	gebaeude = "WC";
	for(int i = 0; i < 3; i++){
			raum+=liefere_ganze_zufallszahl(48,57);
		}
}

void Dienstzimmer::zeige_dienstzimmer(){
	cout << gebaeude << " " << raum << endl;
}
