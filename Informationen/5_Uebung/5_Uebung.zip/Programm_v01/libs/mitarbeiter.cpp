/*
 * mitarbeiter.cpp
 *
 *  Created on: 12.06.2010
 *      Author: jule
 */

#ifndef MITARBEITER_CPP_
#define MITARBEITER_CPP_
#include "Mitarbeiter.h"

Mitarbeiter::Mitarbeiter(){
	funktion = "Schreibkraft";
}

void Mitarbeiter::zeige_person(){
	zeige_person();
	raum.zeige_dienstzimmer();
	telefon.zeige_telefon();
	fax.zeige_telefon();
	email.zeige_email();
	cout << funktion;
}

#endif /* MITARBEITER_CPP_ */
