/*
 * student.cpp
 *
 *  Created on: 12.06.2010
 *      Author: jule
 */

#ifndef STUDENT_CPP_
#define STUDENT_CPP_
#include "Student.h"

Student::Student(){
	fachbereich = "1234";
}
Student::~Student(){

}

void Student::zeige_person(){
	Person::zeige_person();
	cout << fachbereich << endl;
}



#endif /* STUDENT_CPP_ */
