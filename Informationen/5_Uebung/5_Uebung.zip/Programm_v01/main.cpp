/*
 * main.cpp
 *
 *  Created on: 11.06.2010
 *      Author: jule
 */

#include "main.h"

int main(int argc, char **argv) {
	for (int i = 0; i < 3; i++){
		Person *p = 0;
		p = new Mitarbeiter();
		p->zeige_person();
	}
}
