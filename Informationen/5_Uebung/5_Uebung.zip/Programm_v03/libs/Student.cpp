/*
 * student.cpp
 *
 *  Created on: 12.06.2010
 *      Author: jule
 */

#ifndef STUDENT_CPP_
#define STUDENT_CPP_
#include "Student.h"

int matr = 100000;

Student::Student(){
	matrikelnummer = matr++;
}
Student::~Student(){

}

void Student::zeige_person(){
	Person::zeige_person();
	cout << setw(FELDBREITE) <<left << "Matrikelnummer"<<" : " << right << this->matrikelnummer << endl;
	cout << setw(FELDBREITE) <<left << "Fachbereich"<<" : " << right << fb.get_fachbereich() << endl;

}

void Student::erfasse_matrikelnummer(){
	cout << "Bitte geben Sie ihre Matrikelnummer ein";
	cin >> matrikelnummer;
}

void Student::erfasse_person(){
	Person::erfasse_person();
	fb.erfasse_fachbereich();
	sg.erfasse_studiengang();
	erfasse_matrikelnummer();
	imma_datum.erfasse_datum();
	ex_datum.erfasse_datum();
	heimat.erfasse_anschrift();
	email.erfasse_email();
}

int Student::get_matrikelnummer(){
	return this->matrikelnummer;
}


/*
bool cmp_student_matrikelnummer(Student *s1, Student *s2) {
    bool first_arg_before = false;
    if (s1->get_matrikelnummer() < s2->get_matrikelnummer()) {
         first_arg_before = true;
    } else if (s1->get_matrikelnummer() > s2->get_matrikelnummer()) {
         first_arg_before = false;
    } else {
         first_arg_before = true;
    }
    return first_arg_before;
}

void zeige_gemischte_student(vector <Student *> &vect, bool (*cmp)(Student *p1, Student *p2)) {
     if (cmp != 0) {
          sort(vect.begin(), vect.end(), cmp);
     }
     for (unsigned int i = 0; i < vect.size(); i++) {
          vect[i].zeige_person();
     }
}


vector<Person *> erzeuge_studenten(){
	vector <Student *> personenvector;
		for(int i = 0; i < 100; i++){
			Student *p = 0;
			p = new Student;
			personenvector.push_back(p);
		}
		return personenvector;
}
*/
#endif /* STUDENT_CPP_ */
