/*
 * main.h
 *
 *  Created on: 11.06.2010
 *      Author: jule
 */

#ifndef MAIN_H_
#define MAIN_H_
#include <iostream>
using namespace std;
#include "./libs/Person.h"
#include "./libs/Student.h"
#include "./libs/Mitarbeiter.h"


#endif /* MAIN_H_ */
