/*
 * Student.h
 *
 *  Created on: 12.06.2010
 *      Author: jule
 */
#ifndef STUDENT_H_
#define STUDENT_H_
#include "Person.h"
#include "Datum.h"
#include "Email.h"

class Student : public Person{
	private:
		string fachbereich;
		string studiengang;
		string matrikelnummer;
		Datum imma_datum;
		Datum ex_datum;
		Anschrift heimat;
		Email email;

	public:
		Student();
		virtual ~Student();
		virtual void zeige_person();


};

#endif /* STUDENT_H_ */
