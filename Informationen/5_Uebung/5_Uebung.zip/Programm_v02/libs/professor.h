/*
 * professor.h
 *
 *  Created on: 12.06.2010
 *      Author: jule
 */

#ifndef PROFESSOR_H_
#define PROFESSOR_H_
class Professor{
private:
	int test;
public:
	Professor();
	virtual void zeige_person();
};

#endif /* PROFESSOR_H_ */
