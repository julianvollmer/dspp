/*
 * professor.cpp
 *
 *  Created on: 12.06.2010
 *      Author: jule
 */
#ifndef PROFESSOR_CPP_
#define PROFESSOR_CPP_
#include "Professor.h"
#include <iostream>
using namespace std;

Professor::Professor(){
	test = 1;
}

void Professor::zeige_person(){
	cout << test;
}

#endif /* PROFESSOR_CPP_ */
