/*
 * person.h
 *
 *  Created on: 12.06.2010
 *      Author: jule
 */

#ifndef PERSON_H_
#define PERSON_H_
#include "Name.h"
#include "Anschrift.h"
#include "Ort.h"
#include "Telefon.h"
#include "Datum.h"
#include <iostream>
using namespace std;

class Person{
	private:
		Name name;
		Anschrift anschrift;
		string nationalitaet;
		Telefon telefon;
		Datum gebdat;
		Ort gebort;
	public:
		Person();
		virtual ~Person();
		virtual void zeige_person();
};

#endif /* PERSON_H_ */
