/*
 * main.cpp
 *
 *  Created on: 11.06.2010
 *      Author: jule
 */

#include "main.h"

int main(int argc, char **argv) {
	argc = argc;
	argv = argv;

	vector<Person *> p = erzeuge_personen();
	zeige_gemischte_personen(p,cmp_person_nachname_vorname_geb);
}

vector<Person *> erzeuge_personen(){
	vector <Person *> personenvector;
		for(int i = 0; i < 100; i++){
			Person *p = 0;
			p = new Student;
			personenvector.push_back(p);
		}
		return personenvector;
}

void zeige_gemischte_personen(vector <Person *> &vect, bool (*cmp)(Person *p1, Person *p2)) {
     if (cmp != 0) {
          sort(vect.begin(), vect.end(), cmp);
     }
     for (unsigned int i = 0; i < vect.size(); i++) {
          vect[i]->zeige_person();
     }
}

/*
vector<Student *> erzeuge_studenten(){
	vector <Student *> personenvector;
		for(int i = 0; i < 100; i++){
			Student *p = 0;
			p = new Student;
			personenvector.push_back(p);
		}
		return personenvector;
}
*/
/*
vector<Person *> erzeuge_personen_gemischt(int anz){
	vector <Person *> personenvector;
		for(int i = 0; i < anz; i++){
			int auswahl = liefere_ganze_zufallszahl(0,3);
			Person *p = 0;
			if(auswahl == 0)
				p = new Student;
			else if (auswahl == 1)
				p = new Mitarbeiter;
			else if (auswahl == 2)
				p = new Professor;
			else
				p = new Person;
			personenvector.push_back(p);
		}
		return personenvector;
}
	int weiter = 0;
	do{
		weiter = menu();
		if (weiter)
			werte_eingabe_aus(weiter);
	}while (weiter);
}

int menu(){
	string menuepunkte[] = {"Eine bestimmte Anzahl von gemischten Studenten, Beschaeftigte und Professoren erzeugen (1 <= n <= 200)",
							"Personen Alphabetisch sortiert ausgeben(Nachname, Vorname, Geburtsdatum)",
							"Personen nach  Geburtsdatum sortiert ausgeben(Geburtsdatum, Nachname, Vorname)",
							"Personen nach  Geburtsjahr sortiert ausgeben(Geburtsjahr, Nachname, Vorname)",
							"Eine bestimmte Anzahl von  Studenten erzeugen (1 <= n <= 200)",
							"Studenten sortiert ausgeben nach dem Fachbereich (Nachname, Vorname)",
							"Studenten sortiert ausgeben nach der Matrikelnummer",
							"Studenten sortiert ausgeben nach der Matrikelnummer",
							"Studenten sortiert ausgeben nach der Matrikelnummer",
							"n neue Personen erzeugen und sortiert auszugeben(1 <= n <= 200)",
							"Eine bestimmte Anzahl von"};
	int anz_punkte = sizeof(menuepunkte) / sizeof(menuepunkte[0]);

	int weiter;
		loesche_bildschirm_mit_header();
		cout << " Wie moechten Sie fortfahren" << endl << endl;
		for(int i = 0; i < anz_punkte; i++)
			cout <<"(" << i+1 << ")" << menuepunkte[i] << endl;
		cout << "Druecken Sie 0 zum Beeneden" << endl;
		cin >> weiter;
	return weiter;
}

void werte_eingabe_aus(int weiter){
	int auswahl = 0;
	switch(weiter)
	{
		case 1:
			cout << "Bitte geben sie die Anzahl von zu erzeugenden Personen an." << endl;
			cin>>auswahl;
			erzeuge_personen_gemischt(auswahl);
		break;
		case 2:
			cout << "Variable hat den Wert 20." << endl;
		break;
		case 3:
			cout << "Variable hat den Wert 30." << endl;
		break;
		case 4:
			cout << "Variable hat den Wert 40." << endl;
	    break;
		default: erzeuge_studies();
	}
}

void zeige_personen(vector<Person *> p){
	for(unsigned int i = 0; i < p.size(); i++){
		p[i]->zeige_person();
	}
}
void erzeuge_studies(){
	vector <Person *> personenvector;
		for(int i = 0; i < 100; i++){
			Person *p = 0;
			p = new Student();
			personenvector.push_back(p);
		}
}

vector<Person *> erzeuge_personen_gemischt(int anz){
	vector <Person *> personenvector;
		for(int i = 0; i < anz; i++){
			int auswahl = liefere_ganze_zufallszahl(0,3);
			Person *p = 0;
			if(auswahl == 0)
				p = new Student;
			else if (auswahl == 1)
				p = new Mitarbeiter;
			else if (auswahl == 2)
				p = new Professor;
			else
				p = new Person;
			personenvector.push_back(p);
		}
		return personenvector;
}
*/


/*case 9:
               zeige_gemischte_personen(vect, cmp_person_nachname_vorname_geb);
               break;
          case 10:
               zeige_gemischte_personen(vect, cmp_person_geb_nachname_vorname);
               break;
          case 11:
               zeige_gemischte_personen(vect, cmp_person_jahrgang_nachname_vorname);
               break;
*/
