/*
 * main.h
 *
 *  Created on: 11.06.2010
 *      Author: jule
 */

#ifndef MAIN_H_
#define MAIN_H_
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
#include "./libs/Person.h"
#include "./libs/Student.h"
#include "./libs/Mitarbeiter.h"
#include "./libs/Professor.h"
#include "./libs/ausgabe.h"
#include "./libs/mein_zufall.h"
int menu();

vector<Person *> erzeuge_personen();
void werte_eingabe_aus(int weiter);
void zeige_personen(vector<Person *> p);
//vector<Person *>  erzeuge_personen_gemischt(int anz);
void zeige_gemischte_personen(vector <Person *> &vect, bool (*cmp)(Person *p1, Person *p2));
#endif /* MAIN_H_ */
