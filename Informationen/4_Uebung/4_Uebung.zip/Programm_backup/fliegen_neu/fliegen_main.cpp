/*
 * fliegen_main.cpp
 *
 *  Created on: 28.05.2010
 *      Author: julian
 */

#include "fliegen_main.h"

int main(int argc, char *argv[]){
	//if(parameter_ok(argc, argv)){
	cout << "los gehts";
		Flugtag flgtg;
		flgtg.simuliere_fluege();
	//}
	//else
	//	anleitung();
	return 1;

}

bool parameter_ok(int argc, char *argv[]){
	argv = argv;
	argc = argc;
	return true;
}

void anleitung(){
	cout << "Anleitung";
}
