/*
 * fliegen_main.h
 *
 *  Created on: 28.05.2010
 *      Author: julian
 */

#ifndef FLIEGEN_MAIN_H_
#define FLIEGEN_MAIN_H_
#include <iostream>
#include <cstdio>
using namespace std;
#include "./libs/simuliere_fliegen.h"
#include "./libs/Flugtag.h"

void anleitung();
bool parameter_ok(int argc, char *argv[]);
#endif /* FLIEGEN_MAIN_H_ */
