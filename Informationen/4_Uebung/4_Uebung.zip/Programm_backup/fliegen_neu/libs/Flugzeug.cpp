/*
 * Flugzeuge.cpp
 *
 *  Created on: 28.05.2010
 *      Author: julian
 */

#include "Flugzeug.h"

Flugzeug::Flugzeug(){
	this->max_passagiere = 0;
	this->name = "NoN";
}

string Flugzeug::get_name(){
	return this->name;
}

int Flugzeug::get_max_passagiere(){
	return this->max_passagiere;
}

double Flugzeug::get_auslastung(double passagiere_an_board ){
	return (double)(passagiere_an_board / this->max_passagiere) * 100.0;
}


