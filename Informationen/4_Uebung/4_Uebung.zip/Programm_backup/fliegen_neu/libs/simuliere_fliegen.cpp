/*
 * simuliere_fliegen.cpp
 *
 *  Created on: 28.05.2010
 *      Author: julian
 */
#include "simuliere_fliegen.h"

void simuliere_fliegen(int anz){
	Flughafen flughafen;
	vector<Flughafen> fh = init_flughafen_vector(anz);
	//zeige_fh_vector(fh);

	Flug flug;
	cout << flug.get_start();
}

vector<Flughafen> init_flughafen_vector(int anz){
	vector<Flughafen> f;
	for(int i = 0; i < anz; i++){
		Flughafen fh;
		f.push_back(Flughafen(fh));
	}
	return f;
}

void zeige_fh_vector(vector<Flughafen> f){
	for(unsigned int i = 0; i < f.size(); i++){
		cout << f[i].get_name() << endl;
	}
}



