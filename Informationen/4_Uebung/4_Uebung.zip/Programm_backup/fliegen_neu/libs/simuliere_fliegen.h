/*
 * simuliere_fliegen.h
 *
 *  Created on: 28.05.2010
 *      Author: julian
 */

#ifndef SIMULIERE_FLIEGEN_H_
#define SIMULIERE_FLIEGEN_H_
#include <iostream>
#include <vector>
#include "Flughafen.h"
#include "Flug.h"
using namespace std;
vector<Flughafen> init_flughafen_vector(int anz);
void simuliere_fliegen(int anz);
void zeige_fh_vector(vector<Flughafen> f);
#endif /* SIMULIERE_FLIEGEN_H_ */
