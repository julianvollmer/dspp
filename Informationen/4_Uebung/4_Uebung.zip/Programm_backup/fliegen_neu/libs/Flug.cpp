/*
 * Flug.cpp
 *
 *  Created on: 28.05.2010
 *      Author: julian
 */

#include "Flug.h"
Flug::Flug(){
	//this->flieger;
	this->start = "NoN";
	this->ziel = "NoN";
	this->anz_passagiere = liefere_ganze_zufallszahl(0, flieger.get_max_passagiere());
}


string Flug::get_start(){
	return this->start;
}

string Flug::get_ziel(){
	return this->ziel;
}
Flugzeug Flug::get_flieger(){
	return this->flieger;
}

double Flug::get_auslastung(){
	return (((double)this->anz_passagiere) / ((double)this->flieger.get_max_passagiere()) * 100.0);
}

void Flug::set_anz_passagiere(int die_passagiere){
	this->anz_passagiere = die_passagiere;
}


void Flug::set_start(string der_start){
	this->start = der_start;
}
void Flug::set_ziel(string das_ziel){
	this->ziel = das_ziel;
}
