/*
 * Flughafen.cpp
 *
 *  Created on: 28.05.2010
 *      Author: julian
 */
#include "Flughafen.h"

Flughafen::Flughafen(){
	this->max_flieger = 0;
	this->name = this->generiere_name();
}

Flughafen::Flughafen(int die_max_flieger, string der_name){
	this->max_flieger = die_max_flieger;
	this->name = der_name;
}

string Flughafen::get_name(){
	return this->name;
}

int Flughafen::get_max_flieger(){
	return this->max_flieger;
}

string Flughafen::generiere_name(){
	string name;
	for(int i = 0; i < 3; i++){
		name+=liefere_ganze_zufallszahl(65,90);
	}
	return name;
}

vector<Flugzeug> Flughafen::get_flieger(){
	return this->flieger;
}
