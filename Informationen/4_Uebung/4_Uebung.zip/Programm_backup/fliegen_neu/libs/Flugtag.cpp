/*
 * Flugtag.cpp
 *
 *  Created on: 30.05.2010
 *      Author: julian
 */
#include "Flugtag.h"
Flugtag::Flugtag(){

}
void Flugtag::set_flug_geringste_auslastung(Flug flug){
	this->flug_geringste_auslastung = flug;
}
void Flugtag::set_flug_hoechste_auslastung(Flug flug){
	this->flug_hoechste_auslastung = flug;
}
void Flugtag::set_flughafen_geringster_durchsatz(Flughafen flughafen){
	this->flughafen_geringster_durchsatz  = flughafen;
}
void Flugtag::set_flughafen_hoechster_durchsatz(Flughafen flughafen){
	this->flughafen_hoechster_durchsatz = flughafen;
}
Flug Flugtag::get_flug_geringste_auslastung(){
	return this->flug_geringste_auslastung;
}
Flug Flugtag::get_flug_hoechste_auslastung(){
	return this->flug_hoechste_auslastung;
}
Flughafen Flugtag::get_flughafen_geringster_durchsatz(){
	return this->flughafen_geringster_durchsatz;
}
Flughafen Flugtag::get_flughafen_hoechster_durchsatz(){
	return this->flughafen_hoechster_durchsatz;
}
vector<Flughafen> Flugtag::get_flughaefen(){
	return this->flughaefen;
}
void Flugtag::simuliere_fluege(){
	//int anz_fluege = liefere_ganze_zufallszahl(50,70);
	Flugtag f;
	cout << "afdadfasdfasdfsad";
	for(int i = 0; i < 10; i++){
		cout <<"fjsjfosadf";
		f.fliegen();
	}

}

Flughafen Flugtag::suche_ziel(string der_start){
	int auswahl_flughafen = liefere_ganze_zufallszahl(0, (flughaefen.size()-1));
	while((unsigned int)flughaefen[auswahl_flughafen].get_max_flieger() > flughaefen[auswahl_flughafen].get_flieger().size() && flughaefen[auswahl_flughafen].get_name() == der_start ){
		auswahl_flughafen = liefere_ganze_zufallszahl(0, (flughaefen.size()-1));
	}
	return flughaefen[auswahl_flughafen];
}

void Flugtag::fliegen(){

	int auswahl_flughafen = liefere_ganze_zufallszahl(0, (flughaefen.size() - 1));
	int auswahl_flieger = liefere_ganze_zufallszahl(0, (flughaefen[auswahl_flughafen].get_flieger().size() - 1));
	while(flughaefen[auswahl_flughafen].get_flieger().size() == 0){
	//while((int)flughaefen[auswahl_flughafen].get_flieger.size() == 0){
		auswahl_flughafen = liefere_ganze_zufallszahl(0, (flughaefen.size() - 1));
		auswahl_flieger = liefere_ganze_zufallszahl(0, (flughaefen[auswahl_flughafen].get_flieger().size() - 1));
	}
	Flughafen flughafen =  flughaefen[auswahl_flughafen];
	Flugzeug flieger = flughaefen[auswahl_flughafen].get_flieger()[auswahl_flieger];
	int passagiere = liefere_ganze_zufallszahl(0, flieger.get_max_passagiere());
	this->anz_passagiere_ges += passagiere;
	Flug f;
	f.set_anz_passagiere(passagiere);
	f.set_start(flughafen.get_name());
	f.set_ziel(this->suche_ziel(flughafen.get_name()).get_name());


	if(this->get_flug_geringste_auslastung().get_auslastung() > flieger.get_auslastung(passagiere)){
		this->set_flug_geringste_auslastung(f);
	}
	if(this->get_flug_hoechste_auslastung().get_auslastung() < flieger.get_auslastung(passagiere)){
		this->set_flug_hoechste_auslastung(f);
	}
	cout << anz_passagiere_ges;

}
















