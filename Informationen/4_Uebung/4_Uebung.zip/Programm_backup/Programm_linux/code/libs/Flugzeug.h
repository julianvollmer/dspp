/*
 * Flugzeug.h
 *
 *  Created on: 25.05.2010
 *      Author: jule
 */

#ifndef FLUGZEUG_H_
#define FLUGZEUG_H_
#include "mein_zufall.h"
#include <vector>
#include <iostream>
using namespace std;

class Flugzeug{
	private:
		string name;
		int max_passagiere;
	public:
		Flugzeug();
		Flugzeug(string der_name, int die_max_passagiere);
		string get_name();
		int get_max_passagiere();
};

vector<Flugzeug> init_alle_flugzeuge();
Flugzeug waehle_flugzeug_zufaellig();
Flugzeug waehle_flugzeug_aus_vector_zufaellig(vector<Flugzeug> fz);

#endif /* FLUGZEUG_H_ */
