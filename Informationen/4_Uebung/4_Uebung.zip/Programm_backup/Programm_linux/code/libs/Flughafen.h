/*
 * flughafen.h
 *
 *  Created on: 25.05.2010
 *      Author: jule
 */

#ifndef FLUGHAFEN_H_
#define FLUGHAFEN_H_
#include <iostream>
#include <vector>
#include "Flugzeug.h"

using namespace std;

class Flughafen{
	private:
		string name;
		string kuerzel;
		int max_flugzeuge;
		int starts_taeglich;
		int landungen_taeglich;
		int passagiere_durchsatz_landung;
		int passagiere_durchsatz_abflug;
		vector<Flugzeug> flugzeuge;
		void fuelle_flughafen();
	public:
		string get_kuerzel();
		vector<Flugzeug> get_flugzeuge();
		int get_max_flugzeuge();
		int get_passagiere_durchsatz_landung();
		int get_passagiere_durchsatz_abflug();
		void set_flugzeug(Flugzeug f);
		void loesche_flugzeug(Flugzeug f);
		void set_passagiere_durchsatz_landung(int passagiere);
		void set_passagiere_durchsatz_abflug(int passagiere);
		Flughafen();
		Flughafen(string das_kuerzel, int die_max_flugzeuge);
		Flughafen(string der_name, string das_kuerzel, int die_max_flugzeuge);

};

vector<Flughafen> init_flughaefen( int anzahl);

string generiere_kuerzel();
void analysiere_flughaefen (vector<Flughafen> fh);
bool kuerzel_vorhanden(vector<Flughafen> f, Flughafen fh);
#endif /* FLUGHAFEN_H_ */
