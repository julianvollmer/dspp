/*
 * Flughafen.cpp
 *
 *  Created on: 25.05.2010
 *      Author: jule
 */
#include "Flughafen.h"

void Flughafen::fuelle_flughafen(){
	int max_flugzeuge_init = max_flugzeuge / 4;
	for(int i = 0; i < max_flugzeuge_init ; i++){
		Flugzeug f = waehle_flugzeug_zufaellig();
		//cout << f.get_name() << endl;
		flugzeuge.push_back(Flugzeug(f.get_name(),f.get_max_passagiere()));
	}
}

Flughafen::Flughafen(){
	this->name = "NoName";
	this->kuerzel = "NON";
	this->max_flugzeuge =  0;

}

Flughafen::Flughafen(string der_name, string das_kuerzel, int die_max_flugzeuge){
	this->name = der_name;
	this->kuerzel = das_kuerzel;
	this->max_flugzeuge =  die_max_flugzeuge;
	fuelle_flughafen();
}

Flughafen::Flughafen(string das_kuerzel, int die_max_flugzeuge){
	this->name = das_kuerzel;
	this->kuerzel = das_kuerzel;
	this->max_flugzeuge =  die_max_flugzeuge;
	fuelle_flughafen();
}

string Flughafen::get_kuerzel(){
	return this->kuerzel;
}

int Flughafen::get_max_flugzeuge(){
	return this->max_flugzeuge;
}

int Flughafen::get_passagiere_durchsatz_landung(){
	return this->passagiere_durchsatz_landung;
}
int Flughafen::get_passagiere_durchsatz_abflug(){
	return this->passagiere_durchsatz_abflug;
}
vector<Flugzeug> Flughafen::get_flugzeuge(){
	return this->flugzeuge;
}

void Flughafen::set_flugzeug(Flugzeug f){
	flugzeuge.push_back(Flugzeug(f.get_name(),f.get_max_passagiere()));
}

void Flughafen::set_passagiere_durchsatz_landung(int passagiere){
	this->passagiere_durchsatz_landung += passagiere;
}

void Flughafen::set_passagiere_durchsatz_abflug(int passagiere){
	this->passagiere_durchsatz_abflug += passagiere;
}

void Flughafen::loesche_flugzeug(Flugzeug f){
	vector<Flugzeug>::iterator it = flugzeuge.begin();
	for(int i = 0; i < (int)flugzeuge.size(); i++, it++){
		if(flugzeuge[i].get_max_passagiere() == f.get_max_passagiere() && flugzeuge[i].get_name() == f.get_name()){
			//flugzeuge.erase(it);
			i = flugzeuge.size();
		}
	}
}


vector<Flughafen> init_flughaefen( int anzahl){
	vector<Flughafen> f;
	int i = 0;
		do{
			Flughafen fh(generiere_kuerzel(), liefere_ganze_zufallszahl(12,41));
			if( !kuerzel_vorhanden(f, fh) ){
				f.push_back(fh);
				i++;
			}
			else{

			}
		}while(i < anzahl);
	return f;
}

string generiere_kuerzel(){
	string kuerzel;
	for(int i = 0; i < 3; i++){
		kuerzel+=liefere_ganze_zufallszahl(65, 90);
	}
	return kuerzel;
}

bool kuerzel_vorhanden(vector<Flughafen> f, Flughafen fh){
	bool vorhanden = false;
	unsigned int i = 0;
	while(i < f.size()){
		if( f[i].get_kuerzel() == fh.get_kuerzel()){
			vorhanden = true;

		}
		i++;
	}
	return vorhanden;
}


void analysiere_flughaefen (vector<Flughafen> fh){
	for(unsigned int i = 0; i < fh.size();i++){
		cout << fh[i].get_passagiere_durchsatz_abflug() << " ** " << fh[i].get_passagiere_durchsatz_landung() << endl;
	}
}
