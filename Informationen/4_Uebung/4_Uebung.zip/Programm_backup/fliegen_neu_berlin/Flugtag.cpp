/*
 * Flugtag.cpp
 *
 *  Created on: 30.05.2010
 *      Author: julian
 */

#include "Flugtag.h"

