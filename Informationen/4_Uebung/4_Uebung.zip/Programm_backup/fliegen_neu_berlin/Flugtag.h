/*
 * Flugtag.h
 *
 *  Created on: 30.05.2010
 *      Author: julian
 */

#ifndef FLUGTAG_H_
#define FLUGTAG_H_

#include <iostream>
#include <vector>


class Flugtag{
	private:
		Flugzeug flieger_geringste_auslastung;
		Flugzeug flieger_hoechste_auslastung;
		Flughafen flughafen_geringster_durchsatz;
		Flughafen flieger_hoechster_durchsatz;
		vector<Flug> fluege;
		vector<Flughafen> flughaefen;
	public:
		Flugtag();
		void set_flieger_geringste_auslastung(Flugzeug flieger);
		void set_flieger_hoechste_auslastung(Flugzeug flieger);
		void set_flughafen_geringster_durchsatz(Flughafen flughafen);
		void set_flughafen_hoechster_durchsatz(Flughafen);
		Flugzeug get_flieger_geringste_auslastung();
		Flugzeug get_flieger_hoechste_auslastung();
		Flughafen get_flughafen_geringster_durchsatz();
		Flughafen get_flughafen_hoechster_durchsatz();
		vector<Flughaefen> Flugtag::get_flughaefen();
		vector<Flughafen> fliegen(vector<Flughafen> flughaefen);
		void Flugtag::fliegen();
};

#endif /* FLUGTAG_H_ */
