/*
 * Flughafen.cpp
 *
 *  Created on: 25.05.2010
 *      Author: jule
 */
#include "Flughafen.h"

void Flughafen::fuelle_flughafen(){
	int max_flugzeuge_init = max_flugzeuge / 4;
	for(int i = 0; i < max_flugzeuge_init ; i++){
		Flugzeug f = waehle_flugzeug_zufaellig();
		cout << f.get_name() << endl;
		flugzeuge.push_back(Flugzeug(f));
	}
	cout << "flughafen gefuellt" << endl;
}

Flughafen::Flughafen(){
	this->name = "NoName";
	this->kuerzel = "NON";
	this->max_flugzeuge =  0;

}

Flughafen::Flughafen(string der_name, string das_kuerzel, int die_max_flugzeuge){
	this->name = der_name;
	this->kuerzel = das_kuerzel;
	this->max_flugzeuge =  die_max_flugzeuge;
	fuelle_flughafen();
}
vector<Flugzeug> Flughafen::get_flugzeuge(){
	return flugzeuge;
}

vector<Flughafen> init_alle_flughafen(){
	vector<Flughafen> f;
	f.push_back(Flughafen("Berlin Tegel", "TXL", 40));
	f.push_back(Flughafen("Berlin Tegel", "TXL", 40));
	f.push_back(Flughafen("Berlin Tegel", "TXL", 40));
	f.push_back(Flughafen("Berlin Tegel", "TXL", 40));
	f.push_back(Flughafen("Berlin Tegel", "TXL", 40));
	f.push_back(Flughafen("Berlin Tegel", "TXL", 40));
	f.push_back(Flughafen("Berlin Tegel", "TXL", 40));
	f.push_back(Flughafen("Berlin Tegel", "TXL", 40));
	f.push_back(Flughafen("Berlin Tegel", "TXL", 40));
	f.push_back(Flughafen("Berlin Tegel", "TXL", 40));
	f.push_back(Flughafen("Berlin Tegel", "TXL", 40));
	f.push_back(Flughafen("Berlin Tegel", "TXL", 40));
	f.push_back(Flughafen("Berlin Tegel", "TXL", 40));
	f.push_back(Flughafen("Berlin Tegel", "TXL", 40));
	return f;
}

Flughafen waehle_flughafen_zufaellig(){
	vector<Flughafen> fh = init_alle_flughafen();
	return fh[liefere_ganze_zufallszahl(0, fh.size()-1)];
}

Flughafen waehle_flughafen( int pos ){
	vector<Flughafen> fh = init_alle_flughafen();
	pos = pos % fh.size();
	return fh[pos];
}


