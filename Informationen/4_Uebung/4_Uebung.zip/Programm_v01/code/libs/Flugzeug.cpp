/*
 * Flugzeug.cpp
 *
 *  Created on: 25.05.2010
 *      Author: jule
 */

#include "Flugzeug.h"

Flugzeug::Flugzeug(){
	this->name = "kein_name_vorhanden";
	this->max_passagiere = 0;
}

Flugzeug::Flugzeug(string der_name, int die_max_passagiere ){
	this->name = der_name;
	this->max_passagiere = die_max_passagiere;
}

string Flugzeug::get_name(){
	return this->name;
}

int Flugzeug::get_max_passagiere(){
	return this->max_passagiere;
}

vector<Flugzeug> init_alle_flugzeuge(){
	vector<Flugzeug> f;
	f.push_back(Flugzeug("Airbus 320", 174));
	f.push_back(Flugzeug("Airbus 330", 325));
	f.push_back(Flugzeug("Boening 737", 144));
	f.push_back(Flugzeug("Boening 757", 209));
	f.push_back(Flugzeug("Dornier 328", 33));
	f.push_back(Flugzeug("Fokker F10", 100));
	f.push_back(Flugzeug("Learjet 35", 8));
	f.push_back(Flugzeug("McDonnell Douglas MD-88", 152));
	f.push_back(Flugzeug("Saab 340", 33));
	return f;
}

Flugzeug waehle_flugzeug_zufaellig(){
	vector<Flugzeug> fz = init_alle_flugzeuge();
	return fz[liefere_ganze_zufallszahl(0, fz.size())];
}

Flugzeug waehle_flugzeug_aus_vector_zufaellig(vector<Flugzeug> fz){
	return fz[liefere_ganze_zufallszahl(0, fz.size())];
}
