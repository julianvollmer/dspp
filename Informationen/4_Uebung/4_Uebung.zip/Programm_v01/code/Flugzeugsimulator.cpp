/*
 * Flugzeugsimulator.cpp
 *
 *  Created on: 25.05.2010
 *      Author: jule
 */
#include "Flugzeugsimulator.h"

int main(int argc, char *argv[]){
	if(pruefe_parameter(argc, argv)){
		vector<Flughafen> fh;
		for(int i = 0; i < atoi(argv[1]); i++){
			fh.push_back(Flughafen(waehle_flughafen(i)));
		}
		cout << endl << endl <<"hier ist das erste " << fh[0].get_flugzeuge()[0].get_name();
	}
	else
		anleitung();
	return 0;
}

bool pruefe_parameter(int argc, char *argv[]){
	return (argc == 2) && (atoi(argv[1]) >= 5) && (atoi(argv[1]) <= 100);
}

void anleitung(){
	cout << "Bitte starten Sie das Programm in der foldenden Form :" << endl;
	cout << "./Programmname 7" << endl;
	cout << "Programmname = name des Programmes" << endl;
	cout << "7 = Anzahl der Flughaefen [5 - 25]" << endl;
}
