/*
 * Flugzeugsimulator.h
 *
 *  Created on: 25.05.2010
 *      Author: jule
 */

#ifndef FLUGZEUGSIMULATOR_H_
#define FLUGZEUGSIMULATOR_H_
#include "./libs/Flugzeug.h"
#include "./libs/Flughafen.h"
#include <iostream>
using namespace std;
bool pruefe_parameter(int argc, char *argv[]);
void anleitung();

#endif /* FLUGZEUGSIMULATOR_H_ */
