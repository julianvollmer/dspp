/*
 * flughafen.h
 *
 *  Created on: 25.05.2010
 *      Author: jule
 */

#ifndef FLUGHAFEN_H_
#define FLUGHAFEN_H_
#include <iostream>
#include <vector>
#include "Flugzeug.h"

using namespace std;

class Flughafen{
	private:
		string name;
		string kuerzel;
		int max_flugzeuge;
		vector<Flugzeug> flugzeuge;
		void fuelle_flughafen();
	public:
		string get_kuerzel();
		vector<Flugzeug> get_flugzeuge();
		Flughafen();
		Flughafen(string das_kuerzel, int die_max_flugzeuge);
		Flughafen(string der_name, string das_kuerzel, int die_max_flugzeuge);

};

vector<Flughafen> init_alle_flughaefen();
Flughafen waehle_flughafen_zufaellig();
Flughafen waehle_flughafen( int pos );
string generiere_kuerzel();
#endif /* FLUGHAFEN_H_ */
