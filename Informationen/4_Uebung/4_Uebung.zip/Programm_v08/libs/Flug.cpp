/*
 * Flug.cpp
 *
 *  Created on: 28.05.2010
 *      Author: julian
 */

#include "Flug.h"
Flug::Flug(){
	this->start = "NoN";
	this->ziel = "NoN";
	this->auslastung = 50;

}

Flug::Flug(Flugzeug f){
	this->start = "NoN";
	this->ziel = "NoN";
	this->flieger = f;
}


string Flug::get_start(){
	return this->start;
}

string Flug::get_ziel(){
	return this->ziel;
}
Flugzeug Flug::get_flieger(){
	return this->flieger;
}

double Flug::get_auslastung(){
	return auslastung;
}

int Flug::get_anz_passagiere(){
	return this->anz_passagiere;
}

void Flug::set_anz_passagiere(int die_passagiere){
	this->anz_passagiere = die_passagiere;
	double auslastung = ((double)anz_passagiere / (double)flieger.get_max_passagiere())*100;
	this->set_auslastung(auslastung);
}


void Flug::set_start(string der_start){
	this->start = der_start;
}
void Flug::set_ziel(string das_ziel){
	this->ziel = das_ziel;
}

void Flug::set_auslastung(double die_auslastung){
	this->auslastung = die_auslastung;
}
