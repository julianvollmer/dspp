/*
 * Flughafen.cpp
 *
 *  Created on: 25.05.2010
 *      Author: jule
 */
#include "Flughafen.h"

void Flughafen::fuelle_flughafen(){
	int max_flugzeuge_init = max_flugzeuge / 4;
	for(int i = 0; i < max_flugzeuge_init ; i++){
		Flugzeug f = waehle_flugzeug_zufaellig();
		//cout << f.get_name() << endl;
		flugzeuge.push_back(Flugzeug(f.get_name(), f.get_max_passagiere()));
	}
}

Flughafen::Flughafen(){
	this->name = "NoName";
	this->kuerzel = "NON";
	this->max_flugzeuge =  0;

}

Flughafen::Flughafen(string der_name, string das_kuerzel, int die_max_flugzeuge){
	this->name = der_name;
	this->kuerzel = das_kuerzel;
	this->max_flugzeuge =  die_max_flugzeuge;
	fuelle_flughafen();
}

Flughafen::Flughafen(string das_kuerzel, int die_max_flugzeuge){
	this->name = das_kuerzel;
	this->kuerzel = das_kuerzel;
	this->max_flugzeuge =  die_max_flugzeuge;
	fuelle_flughafen();
}

string Flughafen::get_kuerzel(){
	return kuerzel;
}

vector<Flugzeug> Flughafen::get_flugzeuge(){
	return flugzeuge;
}

vector<Flughafen> init_flughaefen( int anzahl){
	vector<Flughafen> f;
	int i = 0;
		do{
			Flughafen fh(generiere_kuerzel(), liefere_ganze_zufallszahl(12,41));
			if( !kuerzel_vorhanden(f, fh) ){
				f.push_back(fh);
				i++;
			}
			else{
				cout << "doppelt " << fh.get_kuerzel() << endl;
			}
		}while(i < anzahl);
	return f;
}
/*
Flughafen waehle_flughafen_zufaellig(){
	vector<Flughafen> fh = init_alle_flughafen();
	return fh[liefere_ganze_zufallszahl(0, fh.size()-1)];
}


Flughafen waehle_flughafen( int pos ){
	vector<Flughafen> fh = init_alle_flughafen();
	pos = pos % fh.size();
	return fh[pos];
}
*/
string generiere_kuerzel(){
	string kuerzel;
	for(int i = 0; i < 3; i++){
		kuerzel+=liefere_ganze_zufallszahl(65, 90);
	}
	return kuerzel;
}

bool kuerzel_vorhanden(vector<Flughafen> f, Flughafen fh){
	bool vorhanden = false;
	unsigned int i = 0;
	while(i < f.size()){
		if( f[i].get_kuerzel() == fh.get_kuerzel()){
			vorhanden = true;

		}
		i++;
	}
	return vorhanden;
}
