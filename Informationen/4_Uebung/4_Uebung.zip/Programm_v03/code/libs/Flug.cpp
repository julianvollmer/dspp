/*
 * flug.cpp
 *
 *  Created on: 26.05.2010
 *      Author: Veronika
 */
#include "Flug.h"
Flug::Flug(){
	this->start_flughafen = "noch nicht geflogen";
	this->end_flughafen =  "noch nicht geflogen";
	this->flugnummer = 0;
}

void Flug::set_start_flughafen(string name){
	this->start_flughafen = name;
}
void Flug::set_end_flughafen(string name){
	this->end_flughafen = name;
}
void Flug::set_flugnummmer(int nummer){
	this->flugnummer = nummer;
}
void Flug::set_flugzeug(Flugzeug f){
	this->flugzeug = f;
}
void Flug::set_anz_passagiere(int passagiere){
	this->anz_passagiere = passagiere;
}
void Flug::set_auslastung(int passagiere){
	//cout << (double)passagiere << "****" << (double)flugzeug.get_max_passagiere() <<endl;
	auslastung = ( (((double)passagiere) / ((double)(flugzeug.get_max_passagiere())) )* 100);
}
int Flug::get_anz_passagiere(){
	return this->anz_passagiere;
}
Flugzeug Flug::get_flugzeug(){
	return this->flugzeug;
}

double Flug::get_auslastung(){
	return this->auslastung;
}

string Flug::get_start_flughafen(){
	return this->start_flughafen;
}

string Flug::get_end_flughafen(){
	return this->end_flughafen;
}
void Flug::zeige_flug(){
	cout 	<< "Endflughafen" << end_flughafen << endl
			<< "Startflughafen" << start_flughafen << endl
			<< "Flugnummer " << flugnummer << endl
			<< "max_pass:" << flugzeug.get_max_passagiere() << endl
			<< "flugzeugname:" << flugzeug.get_name() << endl;
}

Flug fliegen(vector <Flughafen> fh){
	Flug flug;
	unsigned int anz_flughaefen = fh.size();
	int zufalls_flughafen = liefere_ganze_zufallszahl(0, anz_flughaefen - 1);
	Flughafen flughafen = fh[zufalls_flughafen];

	unsigned int anz_flugzeuge = fh[zufalls_flughafen].get_flugzeuge().size();
	int zufalls_flugzeug = liefere_ganze_zufallszahl(0, anz_flugzeuge - 1);
	Flugzeug flieger = fh[zufalls_flughafen].get_flugzeuge()[zufalls_flugzeug];

	flug.set_start_flughafen(flughafen.get_kuerzel());
	flug.set_end_flughafen(flughafen.get_kuerzel());

	flug.set_flugnummmer(123);
	flug.set_anz_passagiere(liefere_ganze_zufallszahl(0,flieger.get_max_passagiere())-1);
	//cout << liefere_ganze_zufallszahl(0,flieger.get_max_passagiere())-1 << "anz pass" <<endl;
	flug.set_flugzeug(flieger);
	flug.set_auslastung(flug.get_anz_passagiere());
	return flug;
}


vector<Flug> simuliere_fluege(vector <Flughafen> fh){
	vector <Flug> fluege;
	int anz_fluege = liefere_ganze_zufallszahl(1,5);
	for(int i = 0; i < anz_fluege; i++){
		fluege.push_back(Flug(fliegen(fh)));
	}

	return fluege;
}



void analysiere_flugtag(vector <Flug> flug , int tag){
	int anz_pass_total = 0;
	int anz_pass_total_max = 0;
	Flug ausgelasteter_flug;
	for(unsigned int i = 0; i < flug.size(); i++){
		anz_pass_total+=flug[i].get_anz_passagiere();
		anz_pass_total_max+=flug[i].get_flugzeug().get_max_passagiere();

		if(ausgelasteter_flug.get_auslastung() < flug[i].get_auslastung() ){
			ausgelasteter_flug = flug[i];
		}
	}

	cout << "---- Tag " << tag << "----" << endl;
	cout << "Fluege:" << flug.size() << endl;
	cout << "Auslastung" << endl;
	cout << "total : " << (((double)anz_pass_total) / ((double)anz_pass_total_max) * 100) << endl;
	cout 	<< "max : " << ausgelasteter_flug.get_start_flughafen() << " -> " << ausgelasteter_flug.get_end_flughafen()
			<< ", " << ausgelasteter_flug.get_anz_passagiere << " von " << ausgelasteter_flug.get_flugzeug().get_max_passagiere() << " ("<< ausgelasteter_flug.get_flugzeug().get_name()<< ") "<< " prozentual: "<< ausgelasteter_flug.get_auslastung() << endl;
	cout << "min : ABC -> CBA, 0 von 152 (MODELL)" << endl;
	cout << "Passagiere abgeflogen" << endl;
	cout << "total " << anz_pass_total << endl;
	cout << "max ABC 8964" << endl;
	cout << "min CBA 1234" << endl;
	cout << "Passagiere angekommen" << endl;
	cout << "total: " << anz_pass_total << endl;
	cout << "max ABC 8964" << endl;
	cout << "min CBA 1234" << endl;
}

/*

*/
