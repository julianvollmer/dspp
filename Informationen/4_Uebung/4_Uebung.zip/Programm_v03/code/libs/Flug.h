/*
 * flug.h
 *
 *  Created on: 26.05.2010
 *      Author: Veronika
 */

#ifndef FLUG_H_
#define FLUG_H_
#include "Flughafen.h"
#include <vector>
#include <iostream>
using namespace std;

class Flug{
	private:
		string start_flughafen;
		string end_flughafen;
		int flugnummer;
		Flugzeug flugzeug;
		int anz_passagiere;
		double auslastung;
	public:
		void set_start_flughafen(string name);
		void set_end_flughafen(string name);
		void set_flugnummmer(int nummer);
		void set_flugzeug(Flugzeug f);
		void set_anz_passagiere(int passagiere);
		void set_auslastung(int passagiere);
		void zeige_flug();
		int get_anz_passagiere();
		double get_auslastung();
		string get_start_flughafen();
		string get_end_flughafen();
		Flugzeug get_flugzeug();
		Flug();
};

vector<Flug> simuliere_fluege(vector <Flughafen> fh);
void zeige_flugtag(vector <Flug> flug, int tag);
void analysiere_flugtag(vector <Flug> flug, int tag);
Flug fliegen(vector <Flughafen> fh);
#endif /* FLUG_H_ */
