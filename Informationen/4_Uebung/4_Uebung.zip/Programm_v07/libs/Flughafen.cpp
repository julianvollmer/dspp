/*
 * Flughafen.cpp
 *
 *  Created on: 28.05.2010
 *      Author: julian
 */
#include "Flughafen.h"

Flughafen::Flughafen(){
	this->max_flieger = liefere_ganze_zufallszahl(12,39);
	this->name = this->generiere_name();
	//init_flieger_zufall(this->max_flieger);
}

Flughafen::Flughafen(int die_max_flieger, string der_name){
	this->max_flieger = die_max_flieger;
	this->name = der_name;
	this->flieger = init_flieger();
}

string Flughafen::get_name(){
	return this->name;
}

int Flughafen::get_max_flieger(){
	return this->max_flieger;
}
void Flughafen::set_name(string der_name){
	this->name = der_name;
}
string Flughafen::generiere_name(){
	string name;
	for(int i = 0; i < 3; i++){
		name+=liefere_ganze_zufallszahl(65,90);
	}
	return name;
}

vector<Flugzeug> Flughafen::get_flieger(){
	return this->flieger;
}



vector<Flugzeug> Flughafen::init_flieger(){
	this->flieger.push_back(Flugzeug("Airbus 320", 174));
	this->flieger.push_back(Flugzeug("Airbus 330", 325));
	this->flieger.push_back(Flugzeug("Boeing 737", 144));
	this->flieger.push_back(Flugzeug("Boeing 757", 209));
	this->flieger.push_back(Flugzeug("Dornier 328", 33));
	this->flieger.push_back(Flugzeug("Fokker F10", 100));
	this->flieger.push_back(Flugzeug("Learjet 35", 8));
	this->flieger.push_back(Flugzeug("McDonnell Douglas MD-88", 152));
	this->flieger.push_back(Flugzeug("Saab 340", 33));
	return this->flieger;
}

void Flughafen::init_flieger_zufall(int anz){

	for(int i  = 0; i < (anz / 2); i++){
		cout << init_flieger()[0].get_max_passagiere();
		//this->flieger.push_back( Flugzeug( this->init_flieger()[liefere_ganze_zufallszahl(0,(this->init_flieger().size() - 1 ))] ));
	}

}
