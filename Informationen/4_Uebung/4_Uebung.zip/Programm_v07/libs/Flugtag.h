/*
 * Flugtag.h
 *
 *  Created on: 30.05.2010
 *      Author: julian
 */

#ifndef FLUGTAG_H_
#define FLUGTAG_H_

#include <iostream>
#include <vector>
using namespace std;

#include "Flughafen.h"
#include "Flug.h"
#include "Flugzeug.h"

//bool ist_erster_tag = false;

class Flugtag{
	private:
		Flug flug_geringste_auslastung;
		Flug flug_hoechste_auslastung;
		Flughafen flughafen_geringster_durchsatz;
		Flughafen flughafen_hoechster_durchsatz;
		vector<Flug> fluege;
		vector<Flughafen> flughaefen;
		int anz_passagiere_ges;
		void init_flughaefen(int anz);

	public:
		Flugtag();
		Flugtag(int anz);
		void set_flug_geringste_auslastung(Flug flieger);
		void set_flug_hoechste_auslastung(Flug flieger);
		void set_flughafen_geringster_durchsatz(Flughafen flughafen);
		void set_flughafen_hoechster_durchsatz(Flughafen);
		Flug get_flug_geringste_auslastung();
		Flug get_flug_hoechste_auslastung();
		Flughafen get_flughafen_geringster_durchsatz();
		Flughafen get_flughafen_hoechster_durchsatz();
		vector<Flughafen> get_flughaefen();
		vector<Flughafen> fliegen(vector<Flughafen> flughaefen);
		void fliegen();
		void simuliere_fluege();
		Flughafen suche_ziel(string der_start);
		void zeige_fluege();
		double get_auslastung();
};

#endif /* FLUGTAG_H_ */
