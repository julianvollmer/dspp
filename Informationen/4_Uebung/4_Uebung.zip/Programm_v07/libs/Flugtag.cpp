/*
 * Flugtag.cpp
 *
 *  Created on: 30.05.2010
 *      Author: julian
 */
#include "Flugtag.h"
Flugtag::Flugtag(){
	int anz = 12;
	init_flughaefen(anz);

}
Flugtag::Flugtag(int anz){
	init_flughaefen(anz);

}
void Flugtag::set_flug_geringste_auslastung(Flug flug){
	this->flug_geringste_auslastung = flug;
}
void Flugtag::set_flug_hoechste_auslastung(Flug flug){
	this->flug_hoechste_auslastung = flug;
}
void Flugtag::set_flughafen_geringster_durchsatz(Flughafen flughafen){
	this->flughafen_geringster_durchsatz  = flughafen;
}
void Flugtag::set_flughafen_hoechster_durchsatz(Flughafen flughafen){
	this->flughafen_hoechster_durchsatz = flughafen;
}
Flug Flugtag::get_flug_geringste_auslastung(){
	return this->flug_geringste_auslastung;
}
Flug Flugtag::get_flug_hoechste_auslastung(){
	return this->flug_hoechste_auslastung;
}
Flughafen Flugtag::get_flughafen_geringster_durchsatz(){
	return this->flughafen_geringster_durchsatz;
}
Flughafen Flugtag::get_flughafen_hoechster_durchsatz(){
	return this->flughafen_hoechster_durchsatz;
}
vector<Flughafen> Flugtag::get_flughaefen(){
	return this->flughaefen;
}
void Flugtag::simuliere_fluege(){
	int anz = liefere_ganze_zufallszahl(5000,7000);
	for(int i = 0; i < anz; i++){
		this->fliegen();
	}

	this->zeige_fluege();
}

double Flugtag::get_auslastung(){
	double auslastung = 0.0;
	for(unsigned int i = 0; i < this->fluege.size();i++){
		auslastung += this->fluege[i].get_auslastung();
	}
	return (auslastung / this->fluege.size());
}

Flughafen Flugtag::suche_ziel(string der_start){
	int auswahl_flughafen = liefere_ganze_zufallszahl(0, (flughaefen.size()-1));
	while((unsigned int)flughaefen[auswahl_flughafen].get_max_flieger() > flughaefen[auswahl_flughafen].get_flieger().size() && flughaefen[auswahl_flughafen].get_name() == der_start ){
		auswahl_flughafen = liefere_ganze_zufallszahl(0, (flughaefen.size()-1));
	}
	return flughaefen[auswahl_flughafen];
}

void Flugtag::fliegen(){

	int auswahl_flughafen = liefere_ganze_zufallszahl(0, (flughaefen.size() - 1));
	int auswahl_flieger = liefere_ganze_zufallszahl(0, (flughaefen[auswahl_flughafen].get_flieger().size() - 1));

	while(flughaefen[auswahl_flughafen].get_flieger().size() == 0){
		auswahl_flughafen = liefere_ganze_zufallszahl(0, (flughaefen.size() - 1));
		auswahl_flieger = liefere_ganze_zufallszahl(0, (flughaefen[auswahl_flughafen].get_flieger().size() - 1));
	}

	Flughafen flughafen =  flughaefen[auswahl_flughafen];
	Flugzeug flieger = flughaefen[auswahl_flughafen].get_flieger()[auswahl_flieger];
	int passagiere = liefere_ganze_zufallszahl(0, flieger.get_max_passagiere());
	this->anz_passagiere_ges += passagiere;
	Flug f(flieger);
	f.set_anz_passagiere(passagiere);
	f.set_start(flughafen.get_name());
	f.set_ziel(this->suche_ziel(flughafen.get_name()).get_name());

	if(this->get_flug_geringste_auslastung().get_auslastung() > flieger.get_auslastung(passagiere)){
		this->set_flug_geringste_auslastung(f);
	}
	if(this->get_flug_hoechste_auslastung().get_auslastung() < flieger.get_auslastung(passagiere)){
		this->set_flug_hoechste_auslastung(f);
	}
	this->fluege.push_back(Flug(f));

}


void Flugtag::init_flughaefen(int anz){
	for(int i = 0; i < anz ; i++){
		Flughafen f;
		this->flughaefen.push_back(Flughafen( f.get_max_flieger(), f.get_name()));
	}

}

void Flugtag::zeige_fluege(){
	cout << "---- Tag 1 ----"<<endl ;
	cout << "Fluege: " << fluege.size()<<endl;
	cout << "Auslastung"<<endl;
	cout << "total: " << get_auslastung() << " %" <<endl;
	cout << "max: " << flug_hoechste_auslastung.get_start() <<" -> " << flug_hoechste_auslastung.get_ziel() << ", ";
	cout << flug_hoechste_auslastung.get_anz_passagiere() << " von "  << flug_hoechste_auslastung.get_flieger().get_max_passagiere() <<endl;
	cout << "min: " << flug_geringste_auslastung.get_start() <<" -> " << flug_geringste_auslastung.get_ziel() << ", ";
	cout << flug_geringste_auslastung.get_anz_passagiere() << " von "  << flug_geringste_auslastung.get_flieger().get_max_passagiere();;
}







