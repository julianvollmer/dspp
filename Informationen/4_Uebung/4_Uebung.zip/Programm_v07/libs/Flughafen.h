/*
 * Flughafen.h
 *
 *  Created on: 28.05.2010
 *      Author: julian
 */

#ifndef FLUGHAFEN_H_
#define FLUGHAFEN_H_
#include <iostream>
#include <vector>

#include "mein_zufall.h"
#include "Flugzeug.h"
using namespace std;


class Flughafen{
	private:
		string name;
		int max_flieger;
		vector<Flugzeug> flieger;
	public:
		Flughafen();
		Flughafen(int die_max_flieger, string der_name);
		string get_name();
		void set_name(string der_name);
		int get_max_flieger();
		string generiere_name();
		vector<Flugzeug> get_flieger();
		vector<Flugzeug> init_flieger();
		void init_flieger_zufall(int anz);
};

#endif /* FLUGHAFEN_H_ */
