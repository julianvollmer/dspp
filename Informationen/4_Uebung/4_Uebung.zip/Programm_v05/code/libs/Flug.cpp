/*
 * flug.cpp
 *
 *  Created on: 26.05.2010
 *      Author: jule
 */
#include "Flug.h"
Flug::Flug(){
	this->start_flughafen = "noch nicht geflogen";
	this->end_flughafen =  "noch nicht geflogen";
	this->flugnummer = 0;
}

Flug::Flug(string start, string ende, int nummer, int die_anz_passagiere, double die_auslastung, Flugzeug das_flugzeug ){
	start_flughafen = start;
	end_flughafen = ende;
	flugnummer = nummer;
	anz_passagiere  = die_anz_passagiere;
	auslastung = die_auslastung;
	flugzeug = das_flugzeug;
}

int Flug::get_flugnummer(){
	return this->flugnummer;
}

void Flug::set_start_flughafen(string name){
	this->start_flughafen = name;
}
void Flug::set_end_flughafen(string name){
	this->end_flughafen = name;
}
void Flug::set_flugnummmer(int nummer){
	this->flugnummer = nummer;
}
void Flug::set_flugzeug(Flugzeug f){
	this->flugzeug = f;
}
void Flug::set_anz_passagiere(int passagiere){
	this->anz_passagiere = passagiere;
}
void Flug::set_auslastung(int passagiere){
	auslastung = ( (((double)passagiere) / ((double)(flugzeug.get_max_passagiere())) )* 100);
}
int Flug::get_anz_passagiere(){
	return this->anz_passagiere;
}
Flugzeug Flug::get_flugzeug(){
	return this->flugzeug;
}

double Flug::get_auslastung(){
	return this->auslastung;
}

string Flug::get_start_flughafen(){
	return this->start_flughafen;
}

string Flug::get_end_flughafen(){
	return this->end_flughafen;
}
void Flug::zeige_flug(){
	cout 	<< "Endflughafen" << end_flughafen << endl
			<< "Startflughafen" << start_flughafen << endl
			<< "Flugnummer " << flugnummer << endl
			<< "max_pass:" << flugzeug.get_max_passagiere() << endl
			<< "flugzeugname:" << flugzeug.get_name() << endl;
}



Flug fliegen(vector <Flughafen> fh){
	Flug flug;
	unsigned int anz_flughaefen = fh.size();
	int zufalls_flughafen = liefere_ganze_zufallszahl(0, (anz_flughaefen - 1));
	Flughafen abflughafen = fh[zufalls_flughafen];

	unsigned int anz_flugzeuge = fh[zufalls_flughafen].get_flugzeuge().size();
	int zufalls_flugzeug = liefere_ganze_zufallszahl(0, (anz_flugzeuge - 1));
	Flugzeug flieger = fh[zufalls_flughafen].get_flugzeuge()[zufalls_flugzeug];

	flug.set_start_flughafen(abflughafen.get_kuerzel());
	Flughafen zielflughafen = suche_zielflughafen(fh, fh[zufalls_flughafen], flieger);
	flug.set_end_flughafen( zielflughafen.get_kuerzel());
	//flug.set_end_flughafen( flughafen.get_kuerzel() );
	flug.set_flugnummmer(123);
	flug.set_anz_passagiere(liefere_ganze_zufallszahl(0,flieger.get_max_passagiere()));
	abflughafen.set_passagiere_durchsatz_abflug(flug.get_anz_passagiere());
	zielflughafen.set_passagiere_durchsatz_landung(flug.get_anz_passagiere());

	flug.set_flugzeug(flieger);
	flug.set_auslastung(flug.get_anz_passagiere());

	return flug;
}




Flughafen suche_zielflughafen(vector <Flughafen> fh, Flughafen start, Flugzeug flugzeug){
	//cout << "hier bnin ich ";
	bool ziel_gefunden = false;
	Flughafen ziel;

	do{
		ziel = fh[liefere_ganze_zufallszahl(0, fh.size()-1)];
		if((ziel.get_max_flugzeuge() > (int)ziel.get_flugzeuge().size()) && ( ziel.get_kuerzel() != start.get_kuerzel())){

		ziel_gefunden = true;
			start.loesche_flugzeug(flugzeug);
			ziel.set_flugzeug(flugzeug);
		}
	}while(!ziel_gefunden);
	return ziel;
}

vector<Flug> simuliere_fluege(vector <Flughafen> fh){
	vector <Flug> fluege;
	int anz_fluege = liefere_ganze_zufallszahl(9000,10000);
	for(int i = 0; i < anz_fluege; i++){
		Flug f = fliegen(fh);
		//cout << f.get_end_flughafen()<<endl;
		fluege.push_back(Flug(f.get_start_flughafen(), f.get_end_flughafen(), f.get_flugnummer(), f.get_anz_passagiere(), f.get_auslastung(), f.get_flugzeug()));
	}
	return fluege;
}


void analysiere_flugtag(vector <Flug> flug , int tag){

	int anz_pass_total = 0;
	int anz_pass_total_max = 0;
	Flug ausgelasteter_flug;
	Flug leerster_flug;
	vector <Flughafen> fh;
	for(unsigned int i = 0; i < flug.size(); i++){

		anz_pass_total+=flug[i].get_anz_passagiere();
		anz_pass_total_max+=flug[i].get_flugzeug().get_max_passagiere();

		if(ausgelasteter_flug.get_auslastung() < flug[i].get_auslastung() ){
			ausgelasteter_flug = flug[i];
		}
		if(leerster_flug.get_auslastung() > flug[i].get_auslastung() ){
			leerster_flug = flug[i];
		}


	}



	cout << "---- Tag " << tag << "----" << endl;
	cout << "Fluege:" << flug.size() << endl;
	cout << "Auslastung" << endl;
	cout << "total : " << (((double)anz_pass_total) / ((double)anz_pass_total_max) * 100) << endl;
	cout 	<< "max : " << ausgelasteter_flug.get_start_flughafen() << " -> " << ausgelasteter_flug.get_end_flughafen();
	cout	<< ", " << ausgelasteter_flug.get_anz_passagiere() << " von " << ausgelasteter_flug.get_flugzeug().get_max_passagiere() << " (" << ausgelasteter_flug.get_flugzeug().get_name()<< ") "<< " prozentual: "<< ausgelasteter_flug.get_auslastung() << endl;

	cout 	<< "min : " << leerster_flug.get_start_flughafen() << " -> " << leerster_flug.get_end_flughafen();
	cout	<< ", " << leerster_flug.get_anz_passagiere() << " von " << leerster_flug.get_flugzeug().get_max_passagiere() << " (" << leerster_flug.get_flugzeug().get_name()<< ") "<< " prozentual: "<< leerster_flug.get_auslastung() << endl;

	cout << "Passagiere abgeflogen" << endl;
	cout << "total " << anz_pass_total << endl;
	cout << "max ABC 8964" << endl;
	cout << "min CBA 1234" << endl;
	cout << "Passagiere angekommen" << endl;
	cout << "total: " << anz_pass_total << endl;
	cout << "max ABC 8964" << endl;
	cout << "min CBA 1234" << endl;
}


