/*
 * Flugzeugsimulator.cpp
 *
 *  Created on: 25.05.2010
 *      Author: jule
 */
#include "Flugzeugsimulator.h"

int main(int argc, char *argv[]) {
	bool erster_start = true;
	int tag = 1;
	vector<Flughafen> fh;
	vector<Flug> flugtag;
	if (pruefe_parameter(argc, argv)) {
		do {
			if (erster_start) {
				fh = init_flughaefen(atoi(argv[1]));
			}
			flugtag = simuliere_fluege(fh);
			//cout << flugtag[0].get_flugzeug().get_name();
			analysiere_flugtag(flugtag, tag);
			analysiere_flughaefen(fh);
			erster_start = false;
			tag++;
		} while(1==2);//while (erfasse_int("Um einen weiteren Tag zu simulieren geben sie bitte 1 ein ")== 1);
	} else
		anleitung();
	return 0;
}

bool pruefe_parameter(int argc, char *argv[]) {
	return (argc == 2) && (atoi(argv[1]) >= 5) && (atoi(argv[1]) <= 100);
}

void anleitung() {
	cout << "Bitte starten Sie das Programm in der foldenden Form :" << endl;
	cout << "./Programmname 7" << endl;
	cout << "Programmname = name des Programmes" << endl;
	cout << "7 = Anzahl der Flughaefen [5 - 100]" << endl;
}
